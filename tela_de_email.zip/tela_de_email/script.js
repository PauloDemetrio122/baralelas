function enviar() //envia a conta nova para o data_base
{
    var email = document.getElementById("_email").value//recebe o valor dos inputs
    var senha = document.getElementById("_senha").value

    
    if(email != "" && !data_base.includes(email) && email.includes("@"))//verifica se o email é válido
    {
        quantidade_de_contas++
        data_base[quantidade_de_contas] = email//define o email no data_base
    }
    else
    {
        if(data_base.includes(email))//se o email já existe
        {
            for(var i=0;i<2;i++)
            {
                var txt = i==0?'Email já existe!':''
                alertas[i].innerText = txt
                
            }
        }
        else
        {
        for(var i=0;i<2;i++)//aplica os aviso de erro nos inputs
            {
                var txt = i==0? 'Email inválido': 'Senha inválida'
                alertas[i].innerText = txt
            }
        }

    }
   
}

function verificar()
{
    var email = document.getElementById("_email").value//recebe o valor dos inputs
    var senha = document.getElementById("_senha").value


    
    if(data_base.includes(email)) //verifica se o email existe
    {
        document.write("Bem vindo de novo ao nosso site!")
    }
    else
    {
        var porque_erro = !data_base.includes(email) ? "Esta conta não existe" : "Email invalido!"
        for(var i=0;i<2;i++)//mostra o porque do erro
        {
            alertas[i].innerText = porque_erro

        }

    }
    
}

function select()//muda o sinal do mouse para pointer
{
    for(var i=0;i<2;i++)
{
    botões[i].style.cursor = 'pointer'
}
}

